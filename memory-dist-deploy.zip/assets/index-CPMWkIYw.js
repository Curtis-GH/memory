(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();function e(){let e=document.getElementById(`app`);if(!e)throw Error(`Mount element #app not found. Check index.html.`);return e}function t(){return{theme:`codeVibes`,player:null,boardSize:null}}function n(e){return e.theme!==null&&e.player!==null&&e.boardSize!==null}function r(e,t){return{...e,theme:t}}function i(e,t){return{...e,player:t}}function a(e,t){return{...e,boardSize:t}}function o(e,t){e.innerHTML=s(),e.querySelector(`.btn--play`)?.addEventListener(`click`,t)}function s(){return`
    <section class="home">
      <div class="home__wrapper">
        <img class="home__controller-icon" src="/home/home-controller.png" alt="" aria-hidden="true" />
        <div class="home__content">
          <div class="home__text-block">
            <p class="home__eyebrow">It's play time.</p>
            <h1 class="home__title">Ready to play?</h1>
          </div>
          ${c()}
        </div>
      </div>
    </section>
  `}function c(){return`
    <div class="home__button-wrap">
      <button class="btn btn--play" type="button">
        <img class="btn__icon" src="/home/home-icon-controller.png" alt="" aria-hidden="true" />
        Play
        <img class="btn__icon" src="/home/home-icon-arrow.png" alt="" aria-hidden="true" />
      </button>
    </div>
  `}var l={codeVibes:{foreground:`/theme/codevibes-card-front.png`,background:`/theme/codevibes-card-back.png`,previewClass:`settings__preview--codeVibes`,headerClass:`preview-header--codeVibes`},gaming:{foreground:`/theme/gaming-card-back.png`,background:`/theme/gaming-card-front.png`,previewClass:`settings__preview--gaming`,headerClass:`preview-header--gaming`}},u=[{value:`codeVibes`,label:`Code vibes theme`},{value:`gaming`,label:`Gaming theme`}],d=[{value:`blue`,label:`Blue`},{value:`orange`,label:`Orange`}],f=[{value:16,label:`16 cards`},{value:24,label:`24 cards`},{value:36,label:`36 cards`}];function p(e,t,n){e.innerHTML=m(t),v(e,t,n),b(e,t),x(e.querySelector(`.settings__preview`),t)}function m(e){return`
    <section class="settings__wrapper">
      <div class="settings__title-row">
        <h1 class="settings__title">Settings</h1>
        <img class="settings__title-divider" src="/settings/settings-divider.png" alt="" aria-hidden="true" />
      </div>
      <div class="settings__body">
        ${ee(e)}
        ${h(e)}
      </div>
    </section>
  `}function h(e){return`
    <div class="settings__preview-column">
      <div class="settings__preview"></div>
      ${te(e)}
    </div>
  `}function ee(e){return`
    <div class="settings__options">
      ${g(`theme`,`Game themes`,`/settings/settings-icon-theme.png`,u,e.theme)}
      ${g(`player`,`Choose player`,`/settings/settings-icon-player.png`,d,e.player)}
      ${g(`boardSize`,`Board size`,`/settings/settings-icon-board-size.png`,f,e.boardSize)}
    </div>
  `}function te(e){let t=`<img class="settings__breadcrumb__divider" src="/settings/settings-breadcrumb-divider.png" alt="" aria-hidden="true" />`;return`
    <div class="settings__breadcrumb">
      <span>Game theme: ${e.theme??`—`}</span>
      ${t}
      <span>Player: ${e.player??`—`}</span>
      ${t}
      <span>Board size: ${e.boardSize??`—`}</span>
      <span class="settings__breadcrumb__spacer"></span>
      ${ne(e)}
    </div>
  `}function ne(e){return`
    <button class="btn btn--start" type="button" ${n(e)?``:`disabled`}>
      <img class="btn__icon" src="/settings/settings-icon-start.png" alt="" aria-hidden="true" />
      Start
    </button>
  `}function g(e,t,n,r,i){return`
    <div class="option-group" data-group="${e}">
      <p class="option-group__label"><img class="option-group__icon" src="${n}" alt="" aria-hidden="true" /> ${t}</p>
      <div class="option-group__list">${r.map(t=>_(e,t,i)).join(``)}</div>
    </div>
  `}function _(e,t,n){let r=n===t.value,i=r?`<img class="option__indicator" src="/settings/settings-active-indicator.png" alt="" aria-hidden="true" />`:``;return`
    <label class="option ${r?`option--active`:``}">
      <input type="radio" name="${e}" value="${t.value}" ${r?`checked`:``} />
      ${t.label}
      ${i}
    </label>
  `}function v(e,t,n){let o=t,s=t=>{o=t,p(e,o,n)};y(e,`theme`,e=>s(r(o,e))),y(e,`player`,e=>s(i(o,e))),y(e,`boardSize`,e=>s(a(o,Number(e)))),e.querySelector(`.btn--start`)?.addEventListener(`click`,()=>n(o))}function y(e,t,n){e.querySelectorAll(`input[name="${t}"]`).forEach(e=>e.addEventListener(`change`,()=>n(e.value)))}function b(e,t){let n=e.querySelector(`.settings__preview`);n&&e.querySelectorAll(`[data-group="theme"] .option`).forEach(e=>{let r=e.querySelector(`input`);r&&e.addEventListener(`mouseenter`,()=>x(n,{...t,theme:r.value}))})}function x(e,t){let n=t.theme;if(!n)return;let{foreground:r,background:i,previewClass:a,headerClass:o}=l[n];e.className=`settings__preview ${a}`,e.innerHTML=`
    ${C(n,o,t.player??`blue`)}
    <div class="preview-cards">
      <img class="preview-cards__card preview-cards__card--background" src="${i}" alt="" aria-hidden="true" />
      <img class="preview-cards__card preview-cards__card--foreground" src="${r}" alt="" aria-hidden="true" />
    </div>
  `}function S(e,t){return e===`gaming`?t===`blue`?`/theme/gaming-icon-player-blue.png`:`/theme/gaming-icon-player-orange.png`:t===`blue`?`/theme/codevibes-icon-player-blue.png`:`/theme/codevibes-icon-player-orange.png`}function C(e,t,n){let r=`<img src="${e===`gaming`?`/theme/gaming-icon-exit-white.png`:`/theme/codevibes-icon-exit.png`}" alt="" aria-hidden="true" />`;return`
    <div class="${t}">
      <span class="badges">
        <span class="player-chip player-chip--blue"><img src="${S(e,`blue`)}" alt="" aria-hidden="true" />Blue 0</span>
        <span class="player-chip player-chip--orange"><img src="${S(e,`orange`)}" alt="" aria-hidden="true" />Orange 0</span>
      </span>
      <span class="current-player">Current player: <img src="${S(e,n)}" alt="" aria-hidden="true" /></span>
      <span class="exit">${r} Exit game</span>
    </div>
  `}var w={codeVibes:[`git`,`typescript`,`javascript`,`html5`,`vscode`,`css3`,`django`,`angular`,`terminal`,`python`,`github`,`nodejs`,`bootstrap`,`vue`,`react`,`sass`,`database`,`firebase`],gaming:[`squidgame-circle`,`squidgame-square`,`squidgame-triangle`,`maze`,`creeper`,`mushroom`,`dice`,`banana`,`controller`,`pacman-ghost`,`star-coin`,`snake`,`level-up`,`pacman`,`gameboy`,`puzzle`,`ace-diamond`,`play-button`]};function T(e,t){return`/board/${e===`codeVibes`?`codevibes`:`gaming`}/icon-${t}.png`}function E(e){return`/board/${e===`codeVibes`?`codevibes`:`gaming`}/card-back.png`}function D(e){let t=[...e];for(let e=t.length-1;e>0;e--){let n=Math.floor(Math.random()*(e+1));[t[e],t[n]]=[t[n],t[e]]}return t}function O(e,t){let n=t/2,r=w[e].slice(0,n);return D([...r,...r]).map((e,t)=>({id:t,iconId:e,status:`hidden`}))}function k(e,t,n){return{theme:e,boardSize:t,cards:O(e,t),currentPlayer:n,scores:{blue:0,orange:0},revealedIds:[]}}function A(e){return e.cards.every(e=>e.status===`matched`)}function j(e,t){let n=e.cards.find(e=>e.id===t);if(!n||n.status!==`hidden`||e.revealedIds.length>=2)return e;let r=e.cards.map(e=>e.id===t?{...e,status:`revealed`}:e);return{...e,cards:r,revealedIds:[...e.revealedIds,t]}}function M(e){return e.revealedIds.length===2}function N(e){let[t,n]=e.revealedIds,r=e.cards.find(e=>e.id===t),i=e.cards.find(e=>e.id===n);if(!r||!i)return e;let a=r.iconId===i.iconId;return{...e,cards:P(e.cards,t,n,a),revealedIds:[],scores:a?F(e.scores,e.currentPlayer):e.scores,currentPlayer:a?e.currentPlayer:L(e.currentPlayer)}}function P(e,t,n,r){let i=r?`matched`:`hidden`;return e.map(e=>e.id===t||e.id===n?{...e,status:i}:e)}function F(e,t){return{...e,[t]:e[t]+1}}function I(e){return e.scores.blue===e.scores.orange?{kind:`draw`}:{kind:`winner`,player:e.scores.blue>e.scores.orange?`blue`:`orange`}}function L(e){return e===`blue`?`orange`:`blue`}var R=900,z={16:4,24:6,36:6},re={codeVibes:{width:`7.5rem`,height:`7.5rem`,gap:{16:`1rem`,24:`0.375rem`,36:`0.375rem`}},gaming:{width:`8.0625rem`,height:`9rem`,gap:{16:`0.5rem`,24:`0.1875rem`,36:`0.1875rem`}}};function B(e){return e===`codeVibes`?`codeVibes`:`gaming`}function V(e,t){return`/theme/${e===`codeVibes`?`codevibes`:`gaming`}-icon-player-${t}.png`}function H(e){return e===`codeVibes`?`/theme/codevibes-icon-exit.png`:`/theme/gaming-icon-exit-white.png`}function U(e,t,n,r){let i=t;e.innerHTML=W(i);let a=()=>i;Y(e,a,e=>{i=e},r),oe(e,a,n)}function W(e){let t=re[e.theme],n=`--columns: ${z[e.boardSize]}; --gap: ${t.gap[e.boardSize]}; --card-width: ${t.width}; --card-height: ${t.height}`;return`
    <section class="board board--${B(e.theme)}">
      <div class="board__wrapper">
        ${G(e)}
        <div class="board__grid" style="${n}">
          ${e.cards.map(t=>q(e,t)).join(``)}
        </div>
      </div>
    </section>
  `}function G(e){let{theme:t,scores:n,currentPlayer:r}=e;return`
    <header class="game-header game-header--${B(t)}">
      <div class="badges badges--${B(t)}">
        <span class="player-chip player-chip--blue"><img src="${V(t,`blue`)}" alt="" aria-hidden="true" /><span data-score="blue">${K(t,`Blue`,n.blue)}</span></span>
        <span class="player-chip player-chip--orange"><img src="${V(t,`orange`)}" alt="" aria-hidden="true" /><span data-score="orange">${K(t,`Orange`,n.orange)}</span></span>
      </div>
      <span class="current-player">Current player: <img data-current-player-icon src="${V(t,r)}" alt="" aria-hidden="true" /></span>
      <button class="exit" type="button">
        <img src="${H(t)}" alt="" aria-hidden="true" /> Exit game
      </button>
    </header>
  `}function K(e,t,n){return e===`codeVibes`?`${t} ${n}`:`${n}`}function q(e,t){let n=J(t),r=t.status===`hidden`?``:`disabled`,i=`<img class="card__face card__face--back" src="${E(e.theme)}" alt="" aria-hidden="true" />`,a=`<img class="card__face card__face--front" src="${T(e.theme,t.iconId)}" alt="" aria-hidden="true" />`;return`
    <button class="card ${n}" type="button" data-card-id="${t.id}" ${r} aria-label="Memory card">
      <span class="card__inner">${i}${a}</span>
    </button>
  `}function J(e){return`${e.status===`hidden`?``:`card--flipped`} ${e.status===`matched`?`card--matched`:``}`.trim()}function Y(e,t,n,r){e.querySelectorAll(`.card`).forEach(i=>{i.addEventListener(`click`,()=>{let a=Number(i.dataset.cardId),o=j(t(),a);o!==t()&&(n(o),Z(i,`flipped`),M(o)&&X(e,t,n,r))})})}function X(e,t,n,r){let{revealedIds:i}=t();setTimeout(()=>{let a=N(t());n(a),ie(e,a,i),ae(e,a),A(a)&&r(a)},R)}function ie(e,t,n){n.forEach(n=>{let r=t.cards.find(e=>e.id===n),i=e.querySelector(`.card[data-card-id="${n}"]`);!r||!i||(r.status===`matched`?i.classList.add(`card--matched`):Z(i,`unflipped`))})}function Z(e,t){e.classList.toggle(`card--flipped`,t===`flipped`),e.disabled=t===`flipped`}function ae(e,t){let n=e.querySelector(`[data-score="blue"]`),r=e.querySelector(`[data-score="orange"]`);n&&(n.textContent=K(t.theme,`Blue`,t.scores.blue)),r&&(r.textContent=K(t.theme,`Orange`,t.scores.orange));let i=e.querySelector(`[data-current-player-icon]`);i&&(i.src=V(t.theme,t.currentPlayer))}function oe(e,t,n){e.querySelector(`.exit`)?.addEventListener(`click`,()=>{se(e,t().theme,n)})}function se(e,t,n){let r=document.createElement(`div`);r.className=`popup-overlay`,r.innerHTML=ce(t),e.appendChild(r),r.addEventListener(`click`,e=>{e.target===r&&r.remove()}),r.querySelector(`.popup__back`)?.addEventListener(`click`,()=>r.remove()),r.querySelector(`.popup__exit`)?.addEventListener(`click`,n)}function ce(e){let t=e===`codeVibes`?`Back to game`:`No, back to game`,n=e===`codeVibes`?`Exit game`:`Yes, quit game`;return`
    <div class="popup popup--${B(e)}">
      <p class="popup__text">Are you sure you want to quit the game?</p>
      <div class="popup__actions">
        <button class="popup__back" type="button">${t}</button>
        <button class="popup__exit" type="button">${n}</button>
      </div>
    </div>
  `}var le=3e3;function ue(e,t,n){e.innerHTML=de(t),setTimeout(()=>{let r=I(t);e.innerHTML=fe(t.theme,r),e.querySelector(`.outcome__button`)?.addEventListener(`click`,n)},le)}function de(e){let t=B(e.theme);return`
    <section class="gameover gameover--${t}">
      <div class="gameover__wrapper">
        <h1 class="gameover__title">Game over</h1>
        <p class="gameover__label">Final score</p>
        <div class="badges badges--${t} gameover__score">
          <span class="player-chip player-chip--blue"><img src="${V(e.theme,`blue`)}" alt="" aria-hidden="true" />${K(e.theme,`Blue`,e.scores.blue)}</span>
          <span class="player-chip player-chip--orange"><img src="${V(e.theme,`orange`)}" alt="" aria-hidden="true" />${K(e.theme,`Orange`,e.scores.orange)}</span>
        </div>
      </div>
    </section>
  `}function fe(e,t){let n=B(e),r=e===`codeVibes`?`Back to start`:`Home`,i=t.kind===`draw`?he():pe(e,t.player);return`
    <section class="gameover gameover--${n} outcome outcome--${t.kind}">
      <div class="gameover__wrapper">
        ${i}
        <button class="outcome__button" type="button">${r}</button>
      </div>
    </section>
  `}function pe(e,t){return e===`codeVibes`?me(t):Q(t)}function me(e){return`
    <img class="outcome__confetti" src="/gameover/gameover-confetti-wide.png" alt="" aria-hidden="true" />
    <p class="outcome__label">The winner is</p>
    <h1 class="outcome__title outcome__title--${e}">${e===`blue`?`Blue`:`Orange`} player</h1>
    <img class="outcome__icon" src="${e===`blue`?`/player/player-token-alt.png`:`/player/player-token.png`}" alt="" />
  `}function Q(e){return`
    <p class="outcome__label">The winner is</p>
    <h1 class="outcome__title outcome__title--${e}">${e===`blue`?`Blue`:`Orange`} Player</h1>
    <img class="outcome__icon outcome__icon--trophy" src="/gameover/gameover-trophy.png" alt="" />
  `}function he(){return`
    <p class="outcome__label">It's a</p>
    <h1 class="outcome__title outcome__title--draw">DRAW</h1>
    <span class="outcome__scale" aria-hidden="true"></span>
  `}function ge(){$(e())}function $(e){o(e,()=>_e(e,t()))}function _e(e,t){p(e,t,t=>ve(e,t))}function ve(e,t){U(e,k(t.theme,t.boardSize,t.player),()=>$(e),t=>ye(e,t))}function ye(e,t){ue(e,t,()=>$(e))}ge();